
<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" />		<title>banquet menu</title>
<meta name='robots' content='max-image-preview:large' />
<script type="text/javascript">/*<![CDATA[ */ var html = document.getElementsByTagName("html")[0]; html.className = html.className.replace("no-js", "js"); window.onerror=function(e,f){var body = document.getElementsByTagName("body")[0]; body.className = body.className.replace("rt-loading", ""); var e_file = document.createElement("a");e_file.href = f;console.log( e );console.log( e_file.pathname );}/* ]]>*/</script>
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Voujon Stonnall | Indian Resturant | Takeaway &raquo; Feed" href="https://voujonstonnall.co.uk/feed/" />
<link rel="alternate" type="application/rss+xml" title="Voujon Stonnall | Indian Resturant | Takeaway &raquo; Comments Feed" href="https://voujonstonnall.co.uk/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/voujonstonnall.co.uk\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.7.2"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='businesslounge-style-all-css'  href='https://voujonstonnall.co.uk/wp-content/themes/businesslounge-9/css/app.min.css?ver=1.7' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-css'  href='https://voujonstonnall.co.uk/wp-content/themes/businesslounge-9/css/woocommerce/woocommerce.min.css?ver=1.7' type='text/css' media='all' />
<link rel='stylesheet' id='fontello-css'  href='https://voujonstonnall.co.uk/wp-content/themes/businesslounge-9/css/fontello/css/fontello.css?ver=1.7' type='text/css' media='all' />
<link rel='stylesheet' id='businesslounge-theme-style-css'  href='https://voujonstonnall.co.uk/wp-content/themes/businesslounge-9/style.css?ver=1.7' type='text/css' media='all' />
<style id='businesslounge-theme-style-inline-css' type='text/css'>
@media (min-width: 768px) and (max-width: 992px) {}@media screen and (max-width: 767px) {}
</style>
<link rel='stylesheet' id='businesslounge-dynamic-css'  href='https://voujonstonnall.co.uk/wp-content/uploads/businesslounge/dynamic-style.css?ver=210131140847' type='text/css' media='all' />
 <link rel='stylesheet' id='businesslounge-dynamic-css'  href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css' type='text/css' media='all' />

<link rel='stylesheet' id='wp-block-library-css'  href='https://voujonstonnall.co.uk/wp-includes/css/dist/block-library/style.min.css?ver=5.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-vendors-style-css'  href='https://voujonstonnall.co.uk/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors-style.css?ver=4.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-style-css'  href='https://voujonstonnall.co.uk/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style.css?ver=4.9.1' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='wcz-frontend-css'  href='https://voujonstonnall.co.uk/wp-content/plugins/woocustomizer/assets/css/frontend.css?ver=2.3.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css'  href='https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.11.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-animations-css'  href='https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=3.2.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-legacy-css'  href='https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/css/frontend-legacy.min.css?ver=3.2.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css'  href='https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.2.4' type='text/css' media='all' />
<style id='elementor-frontend-inline-css' type='text/css'>
@font-face{font-family:eicons;src:url(https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.eot?5.10.0);src:url(https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.eot?5.10.0#iefix) format("embedded-opentype"),url(https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.woff2?5.10.0) format("woff2"),url(https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.woff?5.10.0) format("woff"),url(https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.ttf?5.10.0) format("truetype"),url(https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.svg?5.10.0#eicon) format("svg");font-weight:400;font-style:normal}
</style>
<link rel='stylesheet' id='elementor-post-680-css'  href='https://voujonstonnall.co.uk/wp-content/uploads/elementor/css/post-680.css?ver=1623097771' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-pro-css'  href='https://voujonstonnall.co.uk/wp-content/plugins/elementor-pro/assets/css/frontend.min.css?ver=3.2.2' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-5-all-css'  href='https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/lib/font-awesome/css/all.min.css?ver=3.2.4' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-4-shim-css'  href='https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/lib/font-awesome/css/v4-shims.min.css?ver=3.2.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-851-css'  href='https://voujonstonnall.co.uk/wp-content/uploads/elementor/css/post-851.css?ver=1623121764' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-81-css'  href='https://voujonstonnall.co.uk/wp-content/uploads/elementor/css/post-81.css?ver=1623097771' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-807-css'  href='https://voujonstonnall.co.uk/wp-content/uploads/elementor/css/post-807.css?ver=1623097771' type='text/css' media='all' />
<style id='wcz-customizer-custom-css-inline-css' type='text/css'>
body.wcz-btns.wcz-woocommerce ul.products li.product a.button,
					body.wcz-btns.wcz-woocommerce .related.products ul.products li.product a.button,
					body.wcz-btns.wcz-woocommerce.single-product div.product form.cart .button,
					body.wcz-btns.wcz-woocommerce.single-product .woocommerce-Reviews form.comment-form input.submit,
                    body.wcz-btns.wcz-woocommerce.wcz-wooblocks ul.wc-block-grid__products li.wc-block-grid__product .add_to_cart_button{background-color:#a1741a !important;color:#FFFFFF !important;text-shadow:none;}body.woocommerce.wcz-woocommerce ul.products li.product .woocommerce-loop-product__title,
					body.wcz-woocommerce .products .product .woocommerce-loop-product__title,
                    body.wcz-wooblocks ul.wc-block-grid__products li.wc-block-grid__product .wc-block-grid__product-title a{color:#a1741a !important;}body.woocommerce.wcz-woocommerce ul.products li.product .price,
					body.wcz-woocommerce .products .product .price,
                    body.wcz-wooblocks ul.wc-block-grid__products li.wc-block-grid__product .wc-block-grid__product-price__value,
                    body.wcz-wooblocks ul.wc-block-grid__products li.wc-block-grid__product .wc-block-grid__product-price ins{color:#210000 !important;}body.wcz-wooblocks ul.wc-block-grid__products li.wc-block-grid__product .wc-block-grid__product-price del{color:rgba(33, 0, 0, 0.45);}
</style>
<link rel='stylesheet' id='businesslounge-google-fonts-css'  href='//fonts.googleapis.com/css?family=Montserrat%3A700%2Citalic%7CFira+Sans%3Aregular%2C500%2C400i&#038;subset=latin&#038;ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CMontserrat%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;display=auto&#038;ver=5.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-shared-0-css'  href='https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min.css?ver=5.15.1' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-brands-css'  href='https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.min.css?ver=5.15.1' type='text/css' media='all' />
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-includes/js/jquery/jquery.min.js?ver=3.5.1' id='jquery-core-js'></script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70' id='jquery-blockui-js'></script>
<script type='text/javascript' id='wc-add-to-cart-js-extra'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/voujonstonnall.co.uk\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=5.3.0' id='wc-add-to-cart-js'></script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=5.6' id='vc_woocommerce-add-to-cart-js-js'></script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/lib/font-awesome/js/v4-shims.min.js?ver=3.2.4' id='font-awesome-4-shim-js'></script>
<link rel="https://api.w.org/" href="https://voujonstonnall.co.uk/wp-json/" /><link rel="alternate" type="application/json" href="https://voujonstonnall.co.uk/wp-json/wp/v2/pages/851" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://voujonstonnall.co.uk/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://voujonstonnall.co.uk/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.7.2" />
<meta name="generator" content="WooCommerce 5.3.0" />
<link rel="canonical" href="https://voujonstonnall.co.uk/banquet-menu/" />
<link rel='shortlink' href='https://voujonstonnall.co.uk/?p=851' />
<link rel="alternate" type="application/json+oembed" href="https://voujonstonnall.co.uk/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fvoujonstonnall.co.uk%2Fbanquet-menu%2F" />
<link rel="alternate" type="text/xml+oembed" href="https://voujonstonnall.co.uk/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fvoujonstonnall.co.uk%2Fbanquet-menu%2F&#038;format=xml" />

		<!-- GA Google Analytics @ https://m0n.co/ga -->
		<script>
			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
			ga('create', 'G-4PPK07B43V', 'auto');
			ga('send', 'pageview');
		</script>

	<script type='text/javascript' data-cfasync='false'>var _mmunch = {'front': false, 'page': false, 'post': false, 'category': false, 'author': false, 'search': false, 'attachment': false, 'tag': false};_mmunch['page'] = true; _mmunch['pageData'] = {"ID":851,"post_name":"banquet-menu","post_title":"banquet menu","post_type":"page","post_author":"1","post_status":"publish"};</script><script data-cfasync="false" src="//a.mailmunch.co/app/v1/site.js" id="mailmunch-script" data-plugin="mc_mm" data-mailmunch-site-id="872991" async></script><meta name="generator" content="Powered by BusinessLounge Business WordPress Theme TV:1.7 PV:1.7" />
	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="https://voujonstonnall.co.uk/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>
<body class="page-template-default page page-id-851 theme-businesslounge-9 woocommerce-no-js wcz-woocommerce wcz-btns wcz-btn-style-default  rt-transition overlapped-header sticky-header sticky-header-style-1 header-style-1 header-search-button businesslounge-default-header-width businesslounge-default-footer-width mobile-menu-enabled wpb-js-composer js-comp-ver-5.6 vc_responsive elementor-default elementor-kit-680 elementor-page elementor-page-851">

		<div data-elementor-type="header" data-elementor-id="81" class="elementor elementor-81 elementor-location-header" data-elementor-settings="[]">
		<div class="elementor-section-wrap">
					<section class="elementor-section elementor-top-section elementor-element elementor-element-27dfe4e0 elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default default-style" data-id="27dfe4e0" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;rt_color_sets&quot;:&quot;default-style&quot;}">
						<div class="elementor-container elementor-column-gap-no">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-38931e32" data-id="38931e32" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-482d52d elementor-widget elementor-widget-image" data-id="482d52d" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
<div class="elementor-image">
                                       <a href="<?php echo base_url(); ?>">
                                       <img width="442" height="387" src="<?php echo base_url('assets/logo.png'); ?>" class="attachment-large size-large" alt="" loading="lazy" srcset="<?php echo base_url('assets/logo.png'); ?> 442w, <?php echo base_url('assets/logo.png'); ?> 300w, <?php echo base_url('assets/logo.png'); ?> 221w" sizes="(max-width: 442px) 100vw, 442px"/></a>
                                    </div>
						</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<nav class="elementor-section elementor-top-section elementor-element elementor-element-1af3d62a elementor-section-boxed elementor-section-height-default elementor-section-height-default default-style" data-id="1af3d62a" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;sticky&quot;:&quot;top&quot;,&quot;rt_color_sets&quot;:&quot;default-style&quot;,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}">
						<div class="elementor-container elementor-column-gap-no">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-274c4175" data-id="274c4175" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-79072627 elementor-nav-menu__align-justify elementor-nav-menu--dropdown-mobile elementor-nav-menu--stretch elementor-nav-menu__text-align-center elementor-nav-menu--indicator-classic elementor-nav-menu--toggle elementor-nav-menu--burger elementor-widget elementor-widget-nav-menu" data-id="79072627" data-element_type="widget" data-settings="{&quot;full_width&quot;:&quot;stretch&quot;,&quot;layout&quot;:&quot;horizontal&quot;,&quot;toggle&quot;:&quot;burger&quot;}" data-widget_type="nav-menu.default">
				<div class="elementor-widget-container">
                                    <nav role="navigation" class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-horizontal e--pointer-background e--animation-sweep-right">
                                       <ul id="menu-1-79072627" class="elementor-nav-menu">
                                          <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-77 current_page_item menu-item-151"><a href="<?php echo base_url('Home'); ?>" aria-current="page" class="elementor-item elementor-item-active">Home</a></li>
                                          <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-373"><a href="<?php echo base_url('assets/file/food_menu.pdf'); ?>" target="_blank" class="elementor-item">Menus</a></li>

                                          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-926"><a href="<?php echo base_url(''); ?>" class="elementor-item">Order Online</a></li>
                                          <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-865"><a href="<?php echo base_url('Banquet'); ?>" class="elementor-item">Banquet Menu</a></li>
                                          <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1166"><a href="<?php echo base_url('Booking'); ?>" class="elementor-item">Reservations</a></li>
                                          <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-371"><a href="<?php echo base_url('Contact'); ?>" class="elementor-item">Contact us</a></li>
                                       </ul>
                                    </nav>
                                    <div class="elementor-menu-toggle" role="button" tabindex="0" aria-label="Menu Toggle" aria-expanded="false">
                                       <i class="eicon-menu-bar" aria-hidden="true"></i>
                                       <span class="elementor-screen-only">Menu</span>
                                    </div>
                                    <nav class="elementor-nav-menu--dropdown elementor-nav-menu__container" role="navigation" aria-hidden="true">
                                       <ul id="menu-2-79072627" class="elementor-nav-menu">
                                          <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-77 current_page_item menu-item-151"><a href="<?php echo base_url('Home'); ?>" aria-current="page" class="elementor-item elementor-item-active">Home</a></li>
                                          <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-373"><a href="<?php echo base_url('assets/file/food_menu.pdf'); ?>" target="_blank" class="elementor-item">Menus</a></li>

                                          <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-926"><a href="<?php echo base_url(); ?>" class="elementor-item">Order Online</a></li>
                                          <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-865"><a href="<?php echo base_url('Banquet'); ?>" class="elementor-item">Banquet Menu</a></li>
                                          <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1166"><a href="<?php echo base_url('Booking'); ?>" class="elementor-item">Reservations</a></li>
                                          <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-371"><a href="<?php echo base_url('Contact'); ?>" class="elementor-item">Contact us</a></li>
                                       </ul>
                                    </nav>
                                 </div>
                                 
                                 
                        
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</nav>
				</div>
		</div>
		
	 

						
			>
			
							
				
				<div class='mailmunch-forms-before-post' style='display: none !important;'></div>		<div data-elementor-type="wp-page" data-elementor-id="851" class="elementor elementor-851" data-elementor-settings="[]">
						<div class="elementor-inner">
							<div class="elementor-section-wrap">
							<section class="elementor-section elementor-top-section elementor-element elementor-element-49aacc26 elementor-section-full_width elementor-section-height-min-height elementor-section-content-middle rt-el-parallax-background elementor-section-height-default elementor-section-items-middle default-style" data-id="49aacc26" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;rt_bg_parallax_speed&quot;:&quot;3&quot;,&quot;rt_parallax&quot;:&quot;rt-el-parallax-background&quot;,&quot;rt_color_sets&quot;:&quot;default-style&quot;,&quot;rt_bg_parallax_effect&quot;:&quot;3&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-1c499407" data-id="1c499407" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-2b7c82a7 elementor-widget elementor-widget-heading" data-id="2b7c82a7" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-large">BANQUET MENU
</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-76b3156 elementor-widget elementor-widget-text-editor" data-id="76b3156" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
					<p>Following the new government COVID-19 guidelines for the Cafe Mela and Greater Worcester area, we still plan to provide you Worcester’s best curry* experience –  for you to enjoy at home. From 2nd December we will have your favourite Banquet Nights on Sunday and Wednesday. **</p><p>*as voted for by ‘the Best of Worcester’ marketing feedback<br />** Collection Only</p>					</div>
						</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-28e7774 elementor-section-height-min-height elementor-section-boxed elementor-section-height-default elementor-section-items-middle default-style" data-id="28e7774" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;rt_color_sets&quot;:&quot;default-style&quot;}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-3d911af" data-id="3d911af" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-8442820 elementor-widget elementor-widget-text-editor" data-id="8442820" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
					<p>Sunday £11.95*</p>					</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-d351043 elementor-widget elementor-widget-text-editor" data-id="d351043" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
					<p>Any starter, main course and rice or naan bread from our main menu.</p><div class='mailmunch-forms-in-post-middle' style='display: none !important;'></div>					</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-62d212d elementor-widget elementor-widget-spacer" data-id="62d212d" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-178277e elementor-widget elementor-widget-text-editor" data-id="178277e" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
					<p>Wednesday £12.95*</p>					</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-3679f03 elementor-widget elementor-widget-text-editor" data-id="3679f03" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
					<p>Any starter, main course, vegetable side dish (per couple) and rice or naan bread fromour main menu.</p>					</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-ff5b60c elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="ff5b60c" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-d0a31e1 elementor-widget elementor-widget-text-editor" data-id="d0a31e1" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
					<p>*Duck, seafood, king prawns and crab dishes £2 extra for starter dishes / £3.50 extra for main courses / extra vegetables £1.00 per dish.</p>					</div>
						</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
						</div>
						</div>
					</div><div class='mailmunch-forms-after-post' style='display: none !important;'></div>							

			

			

				

	 
		<div data-elementor-type="footer" data-elementor-id="807" class="elementor elementor-807 elementor-location-footer" data-elementor-settings="[]">
		<div class="elementor-section-wrap">
					<section class="elementor-section elementor-top-section elementor-element elementor-element-7030c9b9 elementor-section-boxed elementor-section-height-default elementor-section-height-default default-style" data-id="7030c9b9" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;rt_color_sets&quot;:&quot;default-style&quot;}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2454b2fa" data-id="2454b2fa" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
                              <div class="elementor-element elementor-element-7abc5c09 elementor-widget elementor-widget-heading" data-id="7abc5c09" data-element_type="widget" data-widget_type="heading.default">
                                 <div class="elementor-widget-container">
                                    <h3 class="elementor-heading-title elementor-size-default">Keep In Touch</h3>
                                 </div>
                              </div>
                              <div class="elementor-element elementor-element-3eb63847 elementor-shape-rounded elementor-grid-0 e-grid-align-center elementor-widget elementor-widget-social-icons" data-id="3eb63847" data-element_type="widget" data-widget_type="social-icons.default">
                                 <div class="elementor-widget-container">
                                    <div class="elementor-social-icons-wrapper elementor-grid">
                                       <div class="elementor-grid-item">
                                          <a class="elementor-icon elementor-social-icon elementor-social-icon-facebook-f elementor-repeater-item-0267196" href="https://www.facebook.com/CafeMelaRestaurant/" target="_blank">
                                          <span class="elementor-screen-only">Facebook-f</span>
                                          <i class="fab fa-facebook-f"></i>					</a>
                                       </div>
                                       <div class="elementor-grid-item">
                                          <a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-repeater-item-8d0505b" href="https://www.instagram.com/cafemela.wr" target="_blank">
                                          <span class="elementor-screen-only">Instagram</span>
                                          <i class="fab fa-instagram"></i>					</a>
                                       </div>
                                       <div class="elementor-grid-item">
                                          <a class="elementor-icon elementor-social-icon elementor-social-icon-tripadvisor elementor-repeater-item-b8b24dd" href="https://www.tripadvisor.co.uk/Restaurant_Review-g186424-d1861175-Reviews-Cafe_Mela_Indian_Restaurant-Worcester_Worcestershire_England.html" target="_blank">
                                          <span class="elementor-screen-only">Tripadvisor</span>
                                          <i class="fab fa-tripadvisor"></i>					</a>
                                       </div>
                                       <!--
                                       <div class="elementor-grid-item">
                                          <a class="elementor-icon elementor-social-icon elementor-social-icon-google-plus-g elementor-repeater-item-5ca709b" href="#" target="_blank">
                                          <span class="elementor-screen-only">Google-plus-g</span>
                                          <i class="fab fa-google-plus-g"></i>					</a>
                                       </div>
                                       -->
                                    </div>
                                 </div>
                              </div>
                           </div>
                           
					</div>
		</div>
								</div>
					</div>
		</section>
                           <section class="elementor-section elementor-inner-section elementor-element elementor-element-49124f4f elementor-section-content-middle elementor-section-height-min-height elementor-section-boxed elementor-section-height-default default-style" data-id="49124f4f" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;rt_color_sets&quot;:&quot;default-style&quot;}">
               <div class="elementor-container elementor-column-gap-no">
                  <div class="elementor-row">
                     <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-14b04708" data-id="14b04708" data-element_type="column">
                        <div class="elementor-column-wrap elementor-element-populated">
                           <div class="elementor-widget-wrap">
                              <div class="elementor-element elementor-element-b9aa5e elementor-widget elementor-widget-heading" data-id="b9aa5e" data-element_type="widget" data-widget_type="heading.default">
                                 <div class="elementor-widget-container">
                                    <h6 class="elementor-heading-title elementor-size-default">Location</h6>
                                 </div>
                              </div>
                              <div class="elementor-element elementor-element-731a5929 elementor-widget elementor-widget-text-editor" data-id="731a5929" data-element_type="widget" data-widget_type="text-editor.default">
                                 <div class="elementor-widget-container">
                                    <div class="elementor-text-editor elementor-clearfix">
                                        <p><span class="LrzXr">22 Forgate Street, Worcester, <br />WR1 1DN</span></p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     
                     <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-32efdfa6" data-id="32efdfa6" data-element_type="column">
                        <div class="elementor-column-wrap elementor-element-populated">
                           <div class="elementor-widget-wrap">
                              <div class="elementor-element elementor-element-476adfba elementor-widget elementor-widget-heading" data-id="476adfba" data-element_type="widget" data-widget_type="heading.default">
                                 <div class="elementor-widget-container">
                                    <h6 class="elementor-heading-title elementor-size-default">Opening Hours</h6>
                                 </div>
                              </div>
                              <div class="elementor-element elementor-element-21d46468 elementor-widget elementor-widget-text-editor" data-id="21d46468" data-element_type="widget" data-widget_type="text-editor.default">
                                 <div class="elementor-widget-container">
                                    <div class="elementor-text-editor elementor-clearfix">
                                       <p style="text-align: center;">Sun to Thu &#8211; 6.00pm to 11.00pm<br />Fri & Sat &#8211; 6.00pm to 12.00am</p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-67fe6a73" data-id="67fe6a73" data-element_type="column">
                        <div class="elementor-column-wrap elementor-element-populated">
                           <div class="elementor-widget-wrap">
                              <div class="elementor-element elementor-element-35fad0db elementor-widget elementor-widget-heading" data-id="35fad0db" data-element_type="widget" data-widget_type="heading.default">
                                 <div class="elementor-widget-container">
                                    <h6 class="elementor-heading-title elementor-size-default">Contact us</h6>
                                 </div>
                              </div>
                              <div class="elementor-element elementor-element-449087f elementor-widget elementor-widget-text-editor" data-id="449087f" data-element_type="widget" data-widget_type="text-editor.default">
                                 <div class="elementor-widget-container">
                                    <div class="elementor-text-editor elementor-clearfix">
                                       <p>Tel: <span style="color: #ffffff;"><a style="color: #ffffff;" href="callto:01922457344">01905 28989 </a></span><br /><span style="color: #ffffff;"><a style="color: #ffffff;" href="mailto:cafemelawr@gmail.com">cafemelawr@gmail.com</a></span></p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <section class="elementor-section elementor-top-section elementor-element elementor-element-4139b75 elementor-section-boxed elementor-section-height-default elementor-section-height-default default-style" data-id="4139b75" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;rt_color_sets&quot;:&quot;default-style&quot;}">
               <div class="elementor-container elementor-column-gap-default">
                  <div class="elementor-row">
                     <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5f55ddc" data-id="5f55ddc" data-element_type="column">
                        <div class="elementor-column-wrap elementor-element-populated">
                           <div class="elementor-widget-wrap">
                              <div class="elementor-element elementor-element-0c8f65d elementor-widget elementor-widget-text-editor" data-id="0c8f65d" data-element_type="widget" data-widget_type="text-editor.default">
                                 <div class="elementor-widget-container">
                                    <div class="elementor-text-editor elementor-clearfix">
                                       <p>© Cafe Mela 2021 All Rights Reserved</p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
         
</div>
		</div>
		
<div class="rt-popup rt-popup-search">
	<div class="rt-popup-content-wrapper">
		<button class="rt-popup-close ui-icon-exit"></button>
		<div class="rt-popup-content">
			<form method="get"  action="https://voujonstonnall.co.uk//"  class="wp-search-form rt_form">
	<ul>
		<li><input type="text" class='search showtextback' placeholder="search" name="s" /><span class="search-icon ui-icon-search-1"></span></li>
	</ul>
	</form>		</div>
	</div>
</div>	
	<div class="rt-popup rt-popup-share">
		<div class="rt-popup-content-wrapper">
			<button class="rt-popup-close ui-icon-exit"></button>
			<div class="rt-popup-content">
				<div class="businesslounge-share-content">				
					<ul></ul>
				</div>
			</div>
		</div>
	</div>
	<div class="side-panel-holder">
	<div class="side-panel-wrapper">
		<div class="side-panel-contents">
<ul id="businesslounge-side-navigation" class="menu"><li id='menu-item-155' data-depth='0' class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home"><a  href="https://voujonstonnall.co.uk/"><span>Home</span></a> </li>
<li id='menu-item-368' data-depth='0' class="menu-item menu-item-type-post_type menu-item-object-page"><a  href="https://voujonstonnall.co.uk/menus/"><span>Menus</span></a> </li>
<li id='menu-item-369' data-depth='0' class="menu-item menu-item-type-post_type menu-item-object-page"><a  href="https://voujonstonnall.co.uk/?page_id=281"><span>Reservations</span></a> </li>
<li id='menu-item-367' data-depth='0' class="menu-item menu-item-type-post_type menu-item-object-page"><a  href="https://voujonstonnall.co.uk/contact-us/"><span>Contact us</span></a> </li>
</ul><div class="side-panel-widgets">
</div>
<div class="widget woocommerce widget_shopping_cart">
<h5>Cart</h5>
<div class="widget_shopping_cart_content"></div>
</div>
		</div>
	</div>
</div>
	<script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
	<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4' id='js-cookie-js'></script>
<script type='text/javascript' id='woocommerce-js-extra'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=5.3.0' id='woocommerce-js'></script>
<script type='text/javascript' id='wc-cart-fragments-js-extra'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_b8c91166efb7667b5b03203062b4b604","fragment_name":"wc_fragments_b8c91166efb7667b5b03203062b4b604","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=5.3.0' id='wc-cart-fragments-js'></script>
<script type='text/javascript' id='businesslounge-scripts-js-extra'>
/* <![CDATA[ */
var rtframework_params = {"ajax_url":"https:\/\/voujonstonnall.co.uk\/wp-admin\/admin-ajax.php","rttheme_template_dir":"https:\/\/voujonstonnall.co.uk\/wp-content\/themes\/businesslounge-9","popup_blocker_message":"Please disable your pop-up blocker and click the \"Open\" link again.","wpml_lang":"","theme_slug":"businesslounge","home_url":"https:\/\/voujonstonnall.co.uk"};
/* ]]> */
</script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/themes/businesslounge-9/js/app.min.js?ver=1.7' id='businesslounge-scripts-js'></script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-includes/js/wp-embed.min.js?ver=5.7.2' id='wp-embed-js'></script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/elementor-pro/assets/lib/smartmenus/jquery.smartmenus.min.js?ver=1.0.1' id='smartmenus-js'></script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/elementor-pro/assets/js/webpack-pro.runtime.min.js?ver=3.2.2' id='elementor-pro-webpack-runtime-js'></script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.2.4' id='elementor-webpack-runtime-js'></script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.2.4' id='elementor-frontend-modules-js'></script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/elementor-pro/assets/lib/sticky/jquery.sticky.min.js?ver=3.2.2' id='elementor-sticky-js'></script>
<script type='text/javascript' id='elementor-pro-frontend-js-before'>
var ElementorProFrontendConfig = {"ajaxurl":"https:\/\/voujonstonnall.co.uk\/wp-admin\/admin-ajax.php","nonce":"0365054aed","urls":{"assets":"https:\/\/voujonstonnall.co.uk\/wp-content\/plugins\/elementor-pro\/assets\/"},"i18n":{"toc_no_headings_found":"No headings were found on this page."},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"google":{"title":"Google+","has_counter":true},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"}},"menu_cart":{"cart_page_url":"https:\/\/voujonstonnall.co.uk\/cart\/","checkout_page_url":"https:\/\/voujonstonnall.co.uk\/checkout\/"},"facebook_sdk":{"lang":"en_US","app_id":""},"lottie":{"defaultAnimationUrl":"https:\/\/voujonstonnall.co.uk\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
</script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.2.2' id='elementor-pro-frontend-js'></script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2' id='elementor-waypoints-js'></script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-includes/js/jquery/ui/core.min.js?ver=1.12.1' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6' id='swiper-js'></script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/lib/share-link/share-link.min.js?ver=3.2.4' id='share-link-js'></script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.8.1' id='elementor-dialog-js'></script>
<script type='text/javascript' id='elementor-frontend-js-before'>
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile","value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Extra","value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet","value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Extra","value":1365,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1620,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"direction":"min","is_enabled":false}}},"version":"3.2.4","is_static":false,"experimentalFeatures":{"form-submissions":true},"urls":{"assets":"https:\/\/voujonstonnall.co.uk\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"page":[],"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":851,"title":"banquet%20menu%20%E2%80%93%20Voujon%20Stonnall%20%7C%20Indian%20Resturant%20%7C%20Takeaway","excerpt":"","featuredImage":false}};
</script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.2.4' id='elementor-frontend-js'></script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/elementor-pro/assets/js/preloaded-elements-handlers.min.js?ver=3.2.2' id='pro-preloaded-elements-handlers-js'></script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/elementor/assets/js/preloaded-modules.min.js?ver=3.2.4' id='preloaded-modules-js'></script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-includes/js/underscore.min.js?ver=1.8.3' id='underscore-js'></script>
<script type='text/javascript' id='wp-util-js-extra'>
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-includes/js/wp-util.min.js?ver=5.7.2' id='wp-util-js'></script>
<script type='text/javascript' id='wpforms-elementor-js-extra'>
/* <![CDATA[ */
var wpformsElementorVars = {"captcha_provider":"recaptcha","recaptcha_type":"v2"};
/* ]]> */
</script>
<script type='text/javascript' src='https://voujonstonnall.co.uk/wp-content/plugins/wpforms/assets/js/integrations/elementor/frontend.min.js?ver=1.6.7' id='wpforms-elementor-js'></script>

</body>
</html>
